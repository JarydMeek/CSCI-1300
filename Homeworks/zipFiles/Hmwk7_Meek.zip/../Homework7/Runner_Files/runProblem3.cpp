// CS1300 Fall 2019
// Author: Jaryd Meek
// Recitation: 102 – Matthew Luebbers
// Homework 7 - Problem 3

#include "../User.cpp"
#include "../userDriver.cpp"

//Test Case 1
//Expected Output
/*
getUsername() returned: Person Name
getNumRatings() returned: 50
users.getRatingAt(0)  = 3
users.getRatingAt(10) = 0
users.getRatingAt(50) = -1
*/
//Test Case 2
//Expected Output
/*
getUsername() returned: Person Name 2
getNumRatings() returned: 10
users2.getRatingAt(0)  = 1
users2.getRatingAt(5) = 1
users2.getRatingAt(10) = 0
*/