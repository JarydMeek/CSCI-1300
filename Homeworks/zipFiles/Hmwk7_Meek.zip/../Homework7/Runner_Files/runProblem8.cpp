// CS1300 Fall 2019
// Author: Jaryd Meek
// Recitation: 102 – Matthew Luebbers
// Homework 7 - Problem 8

#include "../User.cpp"
#include "../book.cpp"
#include "../hw7.cpp"

    //Test Case 1
    /*
    ======Main Menu=====
    1. Read books
    2. Read ratings
    3. Get rating
    4. Find number of books user rated
    5. Get average rating
    6. Quit
    1
    Enter a book file name:
    test
    No books saved to the database.
    ======Main Menu=====
    1. Read books
    2. Read ratings
    3. Get rating
    4. Find number of books user rated
    5. Get average rating
    6. Quit
    6
    Good bye!
    */
    
    
    //Test Case 2
    /*
    ======Main Menu=====
    1. Read books
    2. Read ratings
    3. Get rating
    4. Find number of books user rated
    5. Get average rating
    6. Quit
    1
    Enter a book file name:
    books.txt
    Database is full. Some books may have not been added.
    ======Main Menu=====
    1. Read books
    2. Read ratings
    3. Get rating
    4. Find number of books user rated
    6. Quit
    6
    Good bye!
    */
    