// CS1300 Fall 2019
// Author: Jaryd Meek
// Recitation: 102 – Matthew Luebbers
// Homework 2 - Problem #2

#include <iostream>
using namespace std;

int main () {
    
    //Declare variables
    int classNumber;
    
    //Prompt and store input
    cout<<"Enter a CS course number:"<<endl;
    cin >> classNumber;
    
    //Output Result
    cout<< "Hello, CS " << classNumber << " World!";
    return 0;
}