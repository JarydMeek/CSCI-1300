// CS1300 Fall 2019
// Author: Jaryd Meek
// Recitation: 102 – Matthew Luebbers
// Homework 2 - Problem #3

#include <iostream>
using namespace std;

 //Function for Problem
int classGreeting (int classNumber) {
    //Output Result
    cout << "Hello, CS " << classNumber << " World!";
    return 0;
}

//Function to call classGreeting for Test
 int main () {
     
     classGreeting(1300);
     
 }
